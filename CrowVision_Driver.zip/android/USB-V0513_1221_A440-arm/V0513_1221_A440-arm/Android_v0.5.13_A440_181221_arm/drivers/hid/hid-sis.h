#ifndef __HID_SIS_CTRL_H__
#define __HID_SIS_CTRL_H__

/* ID-table */
#define USB_VENDOR_ID_SIS_TOUCH			0x0457
#define USB_DEVICE_ID_SISF817_TOUCH		0xF817

#define SIS_MT_DEFAULT_MAXCONTACT	10

/* Device node name */
//CONFIG_HID_SIS95XX			// ON/OFF: SiS hydra(6596)/SiS aegis(817)
//#define DEBUG_HID_SIS_UPDATE_FW	// ON/OFF

#if IS_ENABLED(CONFIG_HID_SIS95XX)			//SiS95XX
#define SIS_DEVICE_NAME "sis_hydra_hid_touch_device"
#define SIS_BRIDGE_DEVICE_NAME "sis_hydra_hid_bridge_touch_device"
#else					//SiS92XX
#define SIS_DEVICE_NAME "sis_aegis_hid_touch_device"
#define SIS_BRIDGE_DEVICE_NAME "sis_aegis_hid_bridge_touch_device"
#endif

/* Report id length */
#define	REPORTID_21_LEN	64
#define	REPORTID_25_LEN	320
#define	REPORTID_29_LEN	576
#define	REPORTID_2D_LEN	832

/* SiS debug message */
#ifdef CONFIG_HID_SIS_DBG_POINT
	#define DBG_POINT(fmt, arg...)	printk( fmt, ##arg )
#else
	#define DBG_POINT(...)
#endif	// CONFIG_HID_SIS_DBG_POINT

#ifdef CONFIG_HID_SIS_DBG_MAP_INIT
	#define DBG_MAP(fmt, arg...)	printk( fmt, ##arg )
#else
	#define DBG_MAP(...)
#endif	// CONFIG_HID_SIS_DBG_MAP_INIT

#ifdef CONFIG_DEBUG_HID_SIS_UPDATE_FW
	#define DBG_FW(fmt, arg...)	printk( fmt, ##arg )
	void sis_dbg_dump_array(u8 *ptr, u32 size)
	{
		u32 i;
		for (i=0; i<size; i++)  
		{
			DBG_FW ("%02X ", ptr[i]);
			if( ((i+1)&0xF) == 0)
				DBG_FW ("\n");
		}
		if( size & 0xF)
			DBG_FW ("\n");
	}
#else
	#define DBG_FW(...)
	#define sis_dbg_dump_array(...)
#endif	// CONFIG_DEBUG_HID_SIS_UPDATE_FW


/* SiS Point structure */
struct sis_mt_slot {
	__s32 x, y, p, w, h;
	__s32 contactid;	/* the device ContactID assigned to this slot */
	bool touch_state;	/* is the touch valid? */
	bool seen_in_this_frame;/* has this slot been updated */
};

struct sis_mt_device {
	struct sis_mt_slot curdata;	/* placeholder of incoming data */
	unsigned last_field_index;	/* last field index of the report */
	unsigned last_slot_field;	/* the last field of a slot */
	int last_mt_collection;	/* last known mt-related collection */
	__s8 inputmode;		/* InputMode HID feature, -1 if non-existent */
	__u8 num_received;	/* how many contacts we received */
	__u8 num_expected;	/* expected last contact index */
	__u8 maxcontacts;
	bool curvalid;		/* is the current contact valid? */
	struct sis_mt_slot *slots;
#ifdef CONFIG_SIS_FUNCTIONKEY
	__u8 keybit_state;	/* SiS button */
	__u8 pre_keybit_state;	/* SiS button  */
#endif
};

int sis_cdev_open(struct inode *inode, struct file *filp);
int sis_cdev_release(struct inode *inode, struct file *filp);
ssize_t sis_cdev_read(struct file *file, char __user *buf, size_t count, loff_t *ppos);
ssize_t sis_cdev_write( struct file *file, const char __user *buf, size_t count, loff_t *f_pos );
int sis_setup_chardev(struct hid_device *hdev);
void sis_deinit_chardev(void);

#endif	// __HID_SIS_CTRL_H__
