/*
 *  HID driver for sis 9237/9257 test touchscreens
 */

/*
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 */

#include <linux/device.h>
#include <linux/hid.h>
#include <linux/module.h>
#include <linux/slab.h>
#include <linux/usb.h>
#include <linux/input/mt.h>
#include "usbhid/usbhid.h"
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/version.h>	//LINUX_VERSION_CODE & KERNEL_VERSION

#if LINUX_VERSION_CODE < KERNEL_VERSION(4,12,0)
#include <asm/uaccess.h>	//copy_from_user() & copy_to_user()
#else
#include <linux/uaccess.h>	//copy_from_user() & copy_to_user()
#endif

#include "hid-sis.h"

MODULE_DESCRIPTION("SiS Touchscreen Driver");
MODULE_LICENSE("GPL");

#ifdef CONFIG_HID_SIS_UPDATE_FW
static int sis_char_devs_count = 1;        /* device count */
static int sis_char_major = 0;
static struct cdev sis_char_cdev;
static struct class *sis_char_class = NULL;

static struct hid_device *hid_dev_backup = NULL;  //backup address
static struct urb *backup_urb = NULL;
#endif //#ifdef CONFIG_HID_SIS_UPDATE_FW

static void set_abs(struct input_dev *input, unsigned int code,
		struct hid_field *field)
{
	int fmin = field->logical_minimum;
	int fmax = field->logical_maximum;
	input_set_abs_params(input, code, fmin, fmax, 0, 0);
}

static int sis_mt_input_mapping(struct hid_device *hdev, struct hid_input *hi,
		struct hid_field *field, struct hid_usage *usage,
		unsigned long **bit, int *max)
{
	struct sis_mt_device *td = hid_get_drvdata(hdev);

	/* Only map fields from TouchScreen or TouchPad collections.
         * We need to ignore fields that belong to other collections
         * such as Mouse that might have the same GenericDesktop usages. */
	if (field->application == HID_DG_TOUCHSCREEN)
		set_bit(INPUT_PROP_DIRECT, hi->input->propbit);
	else if (field->application == HID_DG_TOUCHPAD)
		set_bit(INPUT_PROP_POINTER, hi->input->propbit);
	else
		return 0;

	DBG_MAP ("%s: usage->hid = %x\n", __FUNCTION__, usage->hid);	

	switch (usage->hid & HID_USAGE_PAGE) {

	case HID_UP_GENDESK:
		switch (usage->hid) {
		case HID_GD_X:
			hid_map_usage(hi, usage, bit, max,
					EV_ABS, ABS_MT_POSITION_X);
			set_abs(hi->input, ABS_MT_POSITION_X, field);
			/* touchscreen emulation */
			set_abs(hi->input, ABS_X, field);
			if (td->last_mt_collection == usage->collection_index) {
				td->last_slot_field = usage->hid;
				td->last_field_index = field->index;
			}
			return 1;
		case HID_GD_Y:
			hid_map_usage(hi, usage, bit, max,
					EV_ABS, ABS_MT_POSITION_Y);
			set_abs(hi->input, ABS_MT_POSITION_Y, field);
			/* touchscreen emulation */
			set_abs(hi->input, ABS_Y, field);
			if (td->last_mt_collection == usage->collection_index) {
				td->last_slot_field = usage->hid;
				td->last_field_index = field->index;
			}
			return 1;
		}
		return 0;

	case HID_UP_DIGITIZER:
		switch (usage->hid) {
		case HID_DG_TIPSWITCH:
			hid_map_usage(hi, usage, bit, max, EV_KEY, BTN_TOUCH);
			input_set_capability(hi->input, EV_KEY, BTN_TOUCH);
			if (td->last_mt_collection == usage->collection_index) {
				td->last_slot_field = usage->hid;
				td->last_field_index = field->index;
			}
			return 1;
		case HID_DG_CONTACTID:
			td->last_slot_field = usage->hid;
			td->last_field_index = field->index;
			td->last_mt_collection = usage->collection_index;
			return 1;
		case HID_DG_WIDTH:
			hid_map_usage(hi, usage, bit, max,
					EV_ABS, ABS_MT_TOUCH_MAJOR);
			set_abs(hi->input, ABS_MT_TOUCH_MAJOR, field);
			if (td->last_mt_collection == usage->collection_index) {
				td->last_slot_field = usage->hid;
				td->last_field_index = field->index;
			}
			return 1;
		case HID_DG_HEIGHT:
			hid_map_usage(hi, usage, bit, max,
					EV_ABS, ABS_MT_TOUCH_MINOR);
			set_abs(hi->input, ABS_MT_TOUCH_MINOR, field);
			input_set_abs_params(hi->input,
					ABS_MT_ORIENTATION, 0, 1, 0, 0);
			if (td->last_mt_collection == usage->collection_index) {
				td->last_slot_field = usage->hid;
				td->last_field_index = field->index;
			}
			return 1;
		case HID_DG_TIPPRESSURE:
			hid_map_usage(hi, usage, bit, max,
					EV_ABS, ABS_MT_PRESSURE);
			set_abs(hi->input, ABS_MT_PRESSURE, field);
			/* touchscreen emulation */
			set_abs(hi->input, ABS_PRESSURE, field);
			if (td->last_mt_collection == usage->collection_index) {
				td->last_slot_field = usage->hid;
				td->last_field_index = field->index;
			}
			return 1;
		case HID_DG_CONTACTCOUNT:
			if (td->last_mt_collection == usage->collection_index)
				td->last_field_index = field->index;
			td->maxcontacts = field->logical_maximum;
			if (!td->maxcontacts)
				td->maxcontacts = SIS_MT_DEFAULT_MAXCONTACT;
#if LINUX_VERSION_CODE < KERNEL_VERSION(3,7,0)
			input_mt_init_slots(hi->input, td->maxcontacts);
#else
			input_mt_init_slots(hi->input, td->maxcontacts, 0);
#endif
			return 1;
		case HID_DG_CONTACTMAX:
			/* we don't set td->last_slot_field as contactcount and
			 * contact max are global to the report */
			if (td->last_mt_collection == usage->collection_index)
				td->last_field_index = field->index;
			return -1;
		}
		/* let hid-input decide for the others */
		return 0;

	case 0xff000000:
		/* we do not want to map these: no input-oriented meaning */
		return -1;
	}

	return 0;
}

static int sis_mt_input_mapped(struct hid_device *hdev, struct hid_input *hi,
		struct hid_field *field, struct hid_usage *usage,
		unsigned long **bit, int *max)
{
	DBG_MAP ("%s: usage->hid = %x\n", __FUNCTION__, usage->hid);

	if (usage->type == EV_KEY || usage->type == EV_ABS)
		set_bit(usage->type, hi->input->evbit);

	return -1;
}

static int sis_mt_compute_slot(struct sis_mt_device *td)
{
	int i;
	for (i = 0; i < td->maxcontacts; ++i) {
		if (td->slots[i].contactid == td->curdata.contactid &&
			td->slots[i].touch_state)
			return i;
	}
	for (i = 0; i < td->maxcontacts; ++i) {
		if (!td->slots[i].seen_in_this_frame &&
			!td->slots[i].touch_state)
			return i;
	}
	/* should not occurs. If this happens that means
	 * that the device sent more touches that it says
	 * in the report descriptor. It is ignored then. */
	return -1;
}

/*
 * this function is called when a whole contact has been processed,
 * so that it can assign it to a slot and store the data there
 */
static void sis_mt_complete_slot(struct sis_mt_device *td)
{
	td->curdata.seen_in_this_frame = true;
	if (td->curvalid) {
		int slotnum = sis_mt_compute_slot(td);

		if (slotnum >= 0 && slotnum < td->maxcontacts)
			td->slots[slotnum] = td->curdata;
	}
	td->num_received++;
}

#ifdef CONFIG_SIS_FUNCTIONKEY
static void sis_functionkey(struct sis_mt_device *td, struct input_dev *input)
{
	int i = 0;
	u8 diff_keybit_state= 0x0;	/* check keybit_state is difference with pre_keybit_state */
	u8 key_value = 0x0;		/*button location for binary */
	u8  key_pressed = 0x0; 	/*button is up or down */

	diff_keybit_state = td->pre_keybit_state ^ td->keybit_state;

	if (diff_keybit_state)
	{
		for (i = 0; i < 15; i++)
		{
		    if ((diff_keybit_state >> i) & 0x01)
			{
				key_value = diff_keybit_state & (0x01 << i);
				key_pressed = (td->keybit_state >> i) & 0x01;
				switch (key_value)
				{
					case 0x02:
						input_event(input, EV_KEY, KEY_BACK, key_pressed);
						printk(KERN_ERR "%s : MSK_BACK %d \n", __func__ , key_pressed);
						break;
					case 0x04:
						input_event(input, EV_KEY, KEY_MENU, key_pressed);
						printk(KERN_ERR "%s : MSK_MENU %d \n", __func__ , key_pressed);
						break;
					case 0x08:
						input_event(input, EV_KEY, KEY_HOMEPAGE, key_pressed);
						printk(KERN_ERR "%s : MSK_HOME %d \n", __func__ , key_pressed);
						break;
					case 0x0://NO_BTN
						//Release the button if it touched.
					default:
						break;
				}
			}
		}

		td->pre_keybit_state = td->keybit_state;
		input_sync(input);
	}
}
#endif

/*
 * this function is called when a whole packet has been received and processed,
 * so that it can decide what to send to the input layer.
 */
static void sis_mt_emit_event(struct sis_mt_device *td, struct input_dev *input)
{
	int i;

	DBG_POINT("sis_mt_event: finger(s)=%d\n", td->maxcontacts );
	for (i = 0; i < td->maxcontacts; ++i) {
		struct sis_mt_slot *s = &(td->slots[i]);
		if (!s->seen_in_this_frame) {
			s->touch_state = false;
		}

		input_mt_slot(input, i);
		input_mt_report_slot_state(input, MT_TOOL_FINGER,
			s->touch_state);
		if (s->touch_state) {
			/* this finger is on the screen */
			int wide = (s->w > s->h);
			/* divided by two to match visual scale of touch */
			int major = max(s->w, s->h) >> 1;
			int minor = min(s->w, s->h) >> 1;

			input_event(input, EV_ABS, ABS_MT_POSITION_X, s->x);
			input_event(input, EV_ABS, ABS_MT_POSITION_Y, s->y);
			input_event(input, EV_ABS, ABS_MT_ORIENTATION, wide);
			input_event(input, EV_ABS, ABS_MT_PRESSURE, s->p);
			input_event(input, EV_ABS, ABS_MT_TOUCH_MAJOR, major);
			input_event(input, EV_ABS, ABS_MT_TOUCH_MINOR, minor);
		}
		s->seen_in_this_frame = false;

		DBG_POINT("MT_emit_event: slot=%d, id=%d, touch state = %d, x=%d, y=%d, ", i, s->contactid, s->touch_state,s->x, s->y);
		DBG_POINT("pressure=%d, width=%d, height=%d\n", s->p, s->w, s->h);
	}

	input_mt_report_pointer_emulation(input, true);
	input_sync(input);
	td->num_received = 0;
}



static int sis_mt_event(struct hid_device *hid, struct hid_field *field,
				struct hid_usage *usage, __s32 value)
{
	struct sis_mt_device *td = hid_get_drvdata(hid);


	if (hid->claimed & HID_CLAIMED_INPUT && td->slots) {
		switch (usage->hid) {
		case HID_DG_TIPSWITCH:
			td->curvalid = value;
			td->curdata.touch_state = value;
			break;
		case HID_DG_CONTACTID:
			td->curdata.contactid = value;
			break;
		case HID_DG_TIPPRESSURE:
			td->curdata.p = value;
			break;
		case HID_GD_X:
			td->curdata.x = value;
			break;
		case HID_GD_Y:
			td->curdata.y = value;
			break;
		case HID_DG_WIDTH:
			td->curdata.w = value;
			break;
		case HID_DG_HEIGHT:
			td->curdata.h = value;
			break;
		case HID_DG_CONTACTCOUNT:
			/*
			 * Includes multi-packet support where subsequent
			 * packets are sent with zero contactcount.
			 */
			if (value)
				td->num_expected = value;
			break;
#ifdef CONFIG_SIS_FUNCTIONKEY
		case HID_DG_TABLETFUNCTIONKEY:
			DBG_POINT("sis_mt_event : HID_DG_TABLETFUNCTIONKEY = %x\n", value );
			td->keybit_state = value;
			sis_functionkey(td, field->hidinput->input);
			break;
#endif

		default:
			/* fallback to the generic hidinput handling */
			return 0;
		}

		if (usage->hid == td->last_slot_field) {
			sis_mt_complete_slot(td);
		}

		if (field->index == td->last_field_index
			&& td->num_received >= td->num_expected)
			sis_mt_emit_event(td, field->hidinput->input);

	}

	/* we have handled the hidinput part, now remains hiddev */
	if (hid->claimed & HID_CLAIMED_HIDDEV && hid->hiddev_hid_event)
		hid->hiddev_hid_event(hid, field, usage, value);

	return 1;
}

static void sis_mt_set_input_mode(struct hid_device *hdev)
{
	struct sis_mt_device *td = hid_get_drvdata(hdev);
	struct hid_report *r;
	struct hid_report_enum *re;

	if (td->inputmode < 0)
		return;

	re = &(hdev->report_enum[HID_FEATURE_REPORT]);
	r = re->report_id_hash[td->inputmode];
	if (r) {
		r->field[0]->value[0] = 0x02;
#if LINUX_VERSION_CODE < KERNEL_VERSION(3,10,0)
		usbhid_submit_report(hdev, r, USB_DIR_OUT);
#else
		hid_hw_request(hdev, r, HID_REQ_SET_REPORT);
#endif
	}
}

#ifdef CONFIG_HID_SIS_UPDATE_FW
int sis_cdev_open(struct inode *inode, struct file *filp)	//20120306 Yuger ioctl for tool
{
	struct usbhid_device *usbhid; 

	DBG_FW("%s\n" , __FUNCTION__);
	//20110511, Yuger, kill current urb by method of usbhid_stop
	if (!hid_dev_backup) {
		printk(KERN_INFO "(stop)hid_dev_backup is not initialized yet");
		return -1;
	}

	usbhid = hid_dev_backup->driver_data;

	printk(KERN_INFO "sys_sis_HID_stop\n");

	//printk(KERN_INFO "hid_dev_backup->vendor, hid_dev_backup->product = %x %x\n", hid_dev_backup->vendor, hid_dev_backup->product);

	//20110602, Yuger, fix bug: not contact usb cause kernel panic
	if (!usbhid) {
		printk(KERN_INFO "(stop)usbhid is not initialized yet");
		return -1;
	}
	else if (!usbhid->urbin) {
		printk(KERN_INFO "(stop)usbhid->urbin is not initialized yet");
		return -1;
	}
	else if (hid_dev_backup->vendor == USB_VENDOR_ID_SIS_TOUCH) {
		usb_fill_int_urb(backup_urb, usbhid->urbin->dev, usbhid->urbin->pipe,
			usbhid->urbin->transfer_buffer, usbhid->urbin->transfer_buffer_length,
			usbhid->urbin->complete, usbhid->urbin->context, usbhid->urbin->interval);

                clear_bit(HID_STARTED, &usbhid->iofl);
                set_bit(HID_DISCONNECTED, &usbhid->iofl);

                usb_kill_urb(usbhid->urbin);
                usb_free_urb(usbhid->urbin);
                usbhid->urbin = NULL;
		return 0;
	}
    	else {
		printk (KERN_INFO "This is not a SiS device");
		return -801;
	}
}

int sis_cdev_release(struct inode *inode, struct file *filp)
{
	//20110505, Yuger, rebuild the urb which is at the same urb address, then re-submit it

	int ret;
	struct usbhid_device *usbhid;
	unsigned long flags;
	
	DBG_FW("%s: " , __FUNCTION__);
	
	if (!hid_dev_backup) {
		printk(KERN_INFO "(stop)hid_dev_backup is not initialized yet");
		return -1;
	}

	usbhid = hid_dev_backup->driver_data;

	printk(KERN_INFO "sys_sis_HID_start");

	if (!usbhid) {
		printk(KERN_INFO "(start)usbhid is not initialized yet");
		return -1;
	}

	if (!backup_urb) {
		printk(KERN_INFO "(start)backup_urb is not initialized yet");
		return -1;
	}

	clear_bit(HID_DISCONNECTED, &usbhid->iofl);
	usbhid->urbin = usb_alloc_urb(0, GFP_KERNEL);

	if (!backup_urb->interval) {
		printk(KERN_INFO "(start)backup_urb->interval does not exist");
		return -1;
	}

	usb_fill_int_urb(usbhid->urbin, backup_urb->dev, backup_urb->pipe, 
		backup_urb->transfer_buffer, backup_urb->transfer_buffer_length, 
		backup_urb->complete, backup_urb->context, backup_urb->interval);
	usbhid->urbin->transfer_dma = usbhid->inbuf_dma;
	usbhid->urbin->transfer_flags |= URB_NO_TRANSFER_DMA_MAP;

	set_bit(HID_STARTED, &usbhid->iofl);

	//method at hid_start_in
	spin_lock_irqsave(&usbhid->lock, flags);		
	ret = usb_submit_urb(usbhid->urbin, GFP_ATOMIC);
	spin_unlock_irqrestore(&usbhid->lock, flags);
	//yy

	DBG_FW("ret = %d", ret);

	return ret;
}

ssize_t sis_cdev_read(struct file *file, char __user *buf, size_t count, loff_t *ppos)
{
	int timeout = 0;
	u8 *rep_data = NULL;
	u8 *temp_data = NULL;
	u16 size = 0;
	long rep_ret;
	struct usb_interface *intf = to_usb_interface(hid_dev_backup->dev.parent);
	struct usb_device *dev = interface_to_usbdev(intf);
#if IS_ENABLED(CONFIG_HID_SIS95XX)
	u16 reportID = 0;
#else
	int actual_length = 0;
#endif

	DBG_FW( "%s\n", __FUNCTION__ );
	
	temp_data = kzalloc(count, GFP_KERNEL);
	
	if(!temp_data) {
        printk( KERN_INFO "kzalloc temp_data fail\n");
        return (-12);
    }
        
    if ( copy_from_user( temp_data, (void*)buf, count) ) {
		printk( KERN_INFO "copy_from_user(temp_data) fail\n" );
		//free allocated data
		kfree( temp_data );
		temp_data = NULL;
		return -19;
	}

#if IS_ENABLED(CONFIG_HID_SIS95XX)
	switch (temp_data[0]) {
	case 0x21:
		size = (((u16)(temp_data[REPORTID_21_LEN] & 0xff)) << 24)
			+ (((u16)(temp_data[REPORTID_21_LEN + 1] & 0xff)) << 16)
			+ (((u16)(temp_data[REPORTID_21_LEN + 2] & 0xff)) << 8)
			+ (u16)(temp_data[REPORTID_21_LEN + 3] & 0xff);
		timeout = (((int)(temp_data[REPORTID_21_LEN + 4] & 0xff)) << 24)
			+ (((int)(temp_data[REPORTID_21_LEN + 5] & 0xff)) << 16)
			+ (((int)(temp_data[REPORTID_21_LEN + 6 ] & 0xff)) << 8)
			+ (int)(temp_data[REPORTID_21_LEN + 7] & 0xff);
		reportID = 0x0321;
		DBG_FW("%s Report ID : 0x21\n" , __FUNCTION__);
		break;
	case 0x25:
		size = (((u16)(temp_data[REPORTID_25_LEN] & 0xff)) << 24)
			+ (((u16)(temp_data[REPORTID_25_LEN + 1] & 0xff)) << 16)
			+ (((u16)(temp_data[REPORTID_25_LEN + 2] & 0xff)) << 8)
			+ (u16)(temp_data[REPORTID_25_LEN + 3] & 0xff);
		timeout = (((int)(temp_data[REPORTID_25_LEN + 4] & 0xff)) << 24)
			+ (((int)(temp_data[REPORTID_25_LEN + 5] & 0xff)) << 16)
			+ (((int)(temp_data[REPORTID_25_LEN + 6 ] & 0xff)) << 8)
			+ (int)(temp_data[REPORTID_25_LEN + 7] & 0xff);
		reportID = 0x0325;
		DBG_FW("%s Report ID : 0x25\n" , __FUNCTION__);
		break;
	case 0x29:
		size = (((u16)(temp_data[REPORTID_29_LEN] & 0xff)) << 24)
			+ (((u16)(temp_data[REPORTID_29_LEN + 1] & 0xff)) << 16)
			+ (((u16)(temp_data[REPORTID_29_LEN + 2] & 0xff)) << 8)
			+ (u16)(temp_data[REPORTID_29_LEN + 3] & 0xff);
		timeout = (((int)(temp_data[REPORTID_29_LEN + 4] & 0xff)) << 24)
			+ (((int)(temp_data[REPORTID_29_LEN + 5] & 0xff)) << 16)
			+ (((int)(temp_data[REPORTID_29_LEN + 6 ] & 0xff)) << 8)
			+ (int)(temp_data[REPORTID_29_LEN + 7] & 0xff);
		reportID = 0x0329;
		DBG_FW("%s Report ID : 0x29\n" , __FUNCTION__);
		break;
	case 0x2d:
		size = (((u16)(temp_data[REPORTID_2D_LEN] & 0xff)) << 24)
			+ (((u16)(temp_data[REPORTID_2D_LEN + 1] & 0xff)) << 16)
			+ (((u16)(temp_data[REPORTID_2D_LEN + 2] & 0xff)) << 8)
			+ (u16)(temp_data[REPORTID_2D_LEN + 3] & 0xff);
		timeout = (((int)(temp_data[REPORTID_2D_LEN + 4] & 0xff)) << 24)
			+ (((int)(temp_data[REPORTID_2D_LEN + 5] & 0xff)) << 16)
			+ (((int)(temp_data[REPORTID_2D_LEN + 6 ] & 0xff)) << 8)
			+ (int)(temp_data[REPORTID_2D_LEN + 7] & 0xff);
		reportID = 0x032d;
		DBG_FW( "%s Report ID : 0x2d\n" , __FUNCTION__ );
		break;
	default:
		break;
	}
#else
	size = (((u16)(temp_data[64] & 0xff)) << 24) + (((u16)(temp_data[65] & 0xff)) << 16) + 
		(((u16)(temp_data[66] & 0xff)) << 8) + (u16)(temp_data[67] & 0xff);
	timeout = (((int)(temp_data[68] & 0xff)) << 24) + (((int)(temp_data[69] & 0xff)) << 16) + 
		(((int)(temp_data[70] & 0xff)) << 8) + (int)(temp_data[71] & 0xff);
	DBG_FW("%s Report ID : 0x0a\n" , __FUNCTION__);	
#endif

	kfree(temp_data);
    temp_data = NULL;

	DBG_FW("timeout = %d, size %d\n", timeout, size);

	if (!access_ok(VERIFY_WRITE, buf, size)) {
		printk(KERN_INFO "cannot access user space memory\n");
		return -11;
	}

	rep_data = kzalloc(size, GFP_KERNEL);
    if (!rep_data) {
        printk(KERN_INFO "kzalloc rep_data fail\n");
        return -12;
    }

	if (copy_from_user(rep_data, (void*)buf, size)) {
		printk(KERN_INFO "copy_to_user fail(rep_data)\n");
		//free allocated data
		kfree(rep_data);
		rep_data = NULL;
		return -19;
	}

#if IS_ENABLED(CONFIG_HID_SIS95XX)
	rep_ret = usb_control_msg(dev, usb_rcvctrlpipe(dev, 0), 
		0x01, (USB_DIR_IN|USB_TYPE_CLASS|USB_RECIP_INTERFACE), 
		reportID, 0, rep_data, size, timeout);

	DBG_FW("%s: rep_data = ", __FUNCTION__);
	sis_dbg_dump_array(rep_data, 8);

	if (copy_to_user((void*)buf, rep_data, rep_ret)) {
		printk(KERN_INFO "copy_to_user fail(buf)\n");
		//free allocated data
		kfree(rep_data);
		rep_data = NULL;
		return -19;
	}
#else
	rep_ret = usb_interrupt_msg(dev, backup_urb->pipe,
		rep_data, size, &actual_length, timeout);

	DBG_FW("%s: rep_data = ", __FUNCTION__);
	sis_dbg_dump_array(rep_data, 8);

	if (rep_ret == 0) {
		if (copy_to_user((void*)buf, rep_data, actual_length)) {
			printk(KERN_INFO "copy_to_user fail(buf)\n");
			//free allocated data
			kfree(rep_data);
			rep_data = NULL;
			return -19;
		}
	}
#endif

	//free allocated data
	kfree(rep_data);
	rep_data = NULL;
	DBG_FW("%s: rep_ret = %ld\n", __FUNCTION__, rep_ret);
	return rep_ret;
}

ssize_t sis_cdev_write(struct file *file, const char __user *buf, size_t count, loff_t *f_pos)
{
	int timeout = 0;
	u8 *rep_data = NULL;
	u8 *temp_data = NULL;
	u16 size = 0;
	long rep_ret;
	struct usb_interface *intf = to_usb_interface(hid_dev_backup->dev.parent);
	struct usb_device *dev = interface_to_usbdev(intf);
#if IS_ENABLED(CONFIG_HID_SIS95XX)
	u16 reportID = 0;
#else
	int actual_length = 0;
	struct usbhid_device *usbhid = hid_dev_backup->driver_data;
#endif
	
	DBG_FW( "%s\n", __FUNCTION__ );
	
	temp_data = kzalloc(count, GFP_KERNEL);
	
	if(!temp_data)
    {
        printk( KERN_INFO "kzalloc temp_data fail\n");
        return (-12);
    }
        
    if ( copy_from_user( temp_data, (void*)buf, count) ) 
	{
		printk( KERN_INFO "copy_from_user(temp_data) fail\n" );
		//free allocated data
		kfree( temp_data );
		temp_data = NULL;
		return -19;
	}

#if IS_ENABLED(CONFIG_HID_SIS95XX)
	switch (temp_data[0]) {
	case 0x21:
		size = (((u16)(temp_data[REPORTID_21_LEN] & 0xff)) << 24)
			+ (((u16)(temp_data[REPORTID_21_LEN + 1] & 0xff)) << 16)
			+ (((u16)(temp_data[REPORTID_21_LEN + 2] & 0xff)) << 8)
			+ (u16)(temp_data[REPORTID_21_LEN + 3] & 0xff);
		timeout = (((int)(temp_data[REPORTID_21_LEN + 4] & 0xff)) << 24)
			+ (((int)(temp_data[REPORTID_21_LEN + 5] & 0xff)) << 16)
			+ (((int)(temp_data[REPORTID_21_LEN + 6 ] & 0xff)) << 8)
			+ (int)(temp_data[REPORTID_21_LEN + 7] & 0xff);
		reportID = 0x0321;
		DBG_FW("%s Report ID : 0x21\n" , __FUNCTION__);
		break;
	case 0x25:
		size = (((u16)(temp_data[REPORTID_25_LEN] & 0xff)) << 24)
			+ (((u16)(temp_data[REPORTID_25_LEN + 1] & 0xff)) << 16)
			+ (((u16)(temp_data[REPORTID_25_LEN + 2] & 0xff)) << 8)
			+ (u16)(temp_data[REPORTID_25_LEN + 3] & 0xff);
		timeout = (((int)(temp_data[REPORTID_25_LEN + 4] & 0xff)) << 24)
			+ (((int)(temp_data[REPORTID_25_LEN + 5] & 0xff)) << 16)
			+ (((int)(temp_data[REPORTID_25_LEN + 6 ] & 0xff)) << 8)
			+ (int)(temp_data[REPORTID_25_LEN + 7] & 0xff);
		reportID = 0x0325;
		DBG_FW("%s Report ID : 0x25\n" , __FUNCTION__);
		break;
	case 0x29:
		size = (((u16)(temp_data[REPORTID_29_LEN] & 0xff)) << 24)
			+ (((u16)(temp_data[REPORTID_29_LEN + 1] & 0xff)) << 16)
			+ (((u16)(temp_data[REPORTID_29_LEN + 2] & 0xff)) << 8)
			+ (u16)(temp_data[REPORTID_29_LEN + 3] & 0xff);
		timeout = (((int)(temp_data[REPORTID_29_LEN + 4] & 0xff)) << 24)
			+ (((int)(temp_data[REPORTID_29_LEN + 5] & 0xff)) << 16)
			+ (((int)(temp_data[REPORTID_29_LEN + 6 ] & 0xff)) << 8)
			+ (int)(temp_data[REPORTID_29_LEN + 7] & 0xff);
		reportID = 0x0329;
		DBG_FW("%s Report ID : 0x29\n" , __FUNCTION__);
		break;
	case 0x2d:
		size = (((u16)(temp_data[REPORTID_2D_LEN] & 0xff)) << 24)
			+ (((u16)(temp_data[REPORTID_2D_LEN + 1] & 0xff)) << 16)
			+ (((u16)(temp_data[REPORTID_2D_LEN + 2] & 0xff)) << 8)
			+ (u16)(temp_data[REPORTID_2D_LEN + 3] & 0xff);
		timeout = (((int)(temp_data[REPORTID_2D_LEN + 4] & 0xff)) << 24)
			+ (((int)(temp_data[REPORTID_2D_LEN + 5] & 0xff)) << 16)
			+ (((int)(temp_data[REPORTID_2D_LEN + 6 ] & 0xff)) << 8)
			+ (int)(temp_data[REPORTID_2D_LEN + 7] & 0xff);
		reportID = 0x032d;
		DBG_FW("%s Report ID : 0x2d\n" , __FUNCTION__);
		break;
	default:
		break;
	}
#else
	size = (((u16)(temp_data[64] & 0xff)) << 24) + (((u16)(temp_data[65] & 0xff)) << 16) + 
		(((u16)(temp_data[66] & 0xff)) << 8) + (u16)(temp_data[67] & 0xff);
	timeout = (((int)(temp_data[68] & 0xff)) << 24) + (((int)(temp_data[69] & 0xff)) << 16) + 
		(((int)(temp_data[70] & 0xff)) << 8) + (int)(temp_data[71] & 0xff);
	DBG_FW("%s Report ID : 0x09\n" , __FUNCTION__);
#endif

	DBG_FW("timeout = %d, size %d\n", timeout, size);
	
	kfree(temp_data);
    temp_data = NULL;

	if (!access_ok(VERIFY_WRITE, buf, size)) {
		printk(KERN_INFO "cannot access user space memory\n");
		return -11;
	}

	rep_data = kzalloc(size, GFP_KERNEL);
	if (!rep_data) {
        printk(KERN_INFO "kzalloc rep_data fail\n");
        return -12;
    }

	if (copy_from_user(rep_data, (void*)buf, size)) {
		printk(KERN_INFO "copy_to_user fail(rep_data)\n");
		//free allocated data
		kfree(rep_data);
		rep_data = NULL;
		return -19;
	}

#if IS_ENABLED(CONFIG_HID_SIS95XX)
	rep_ret = usb_control_msg(dev, usb_sndctrlpipe(dev, 0), 
		0x09, (USB_DIR_OUT|USB_TYPE_CLASS|USB_RECIP_INTERFACE), 
		reportID, 0, rep_data, size, timeout);

	DBG_FW("%s: rep_data = ", __FUNCTION__);
	sis_dbg_dump_array(rep_data, 8);

	if (copy_to_user((void*)buf, rep_data, rep_ret)) {
		printk(KERN_INFO "copy_to_user fail(buf)\n");
		//free allocated data
		kfree(rep_data);
		rep_data = NULL;
		return -19;
	}
#else
	rep_ret = usb_interrupt_msg(dev, usbhid->urbout->pipe,
		rep_data, size, &actual_length, timeout);

	DBG_FW("%s: rep_data = ", __FUNCTION__);
	sis_dbg_dump_array(rep_data, size);
	
	if (rep_ret == 0) {
		if (copy_to_user((void*)buf, rep_data, actual_length)) {
			printk(KERN_INFO "copy_to_user fail(buf)\n");
			//free allocated data
			kfree(rep_data);
			rep_data = NULL;
			return -19;
		}
	}
#endif		

	DBG_FW("%s: rep_ret = %ld\n", __FUNCTION__, rep_ret);
	//free allocated data
	kfree(rep_data);
	rep_data = NULL;
	DBG_FW("End of sys_sis_HID_IO\n");
	return rep_ret;
}


//for ioctl
static const struct file_operations sis_cdev_fops = {
	.owner	= THIS_MODULE,
	.read	= sis_cdev_read,
	.write	= sis_cdev_write,
	.open	= sis_cdev_open,
	.release= sis_cdev_release,
};

//for ioctl
int sis_setup_chardev(struct hid_device *hdev)
{
	
	dev_t dev = MKDEV(sis_char_major, 0);
	int alloc_ret = 0;
	int cdev_err = 0;
	int input_err = 0;
	struct device *class_dev = NULL;
	void *ptr_err;
	
	printk("sis_setup_chardev.\n");
	hid_dev_backup = hdev;
	
	backup_urb = usb_alloc_urb(0, GFP_KERNEL); //0721test
	if (!backup_urb) {
		dev_err(&hdev->dev, "cannot allocate backup_urb\n");
		return -ENOMEM;
	}

	// dynamic allocate driver handle
	if (hdev->product == USB_DEVICE_ID_SISF817_TOUCH)
		alloc_ret = alloc_chrdev_region(&dev, 0, sis_char_devs_count, SIS_BRIDGE_DEVICE_NAME);
	else
		alloc_ret = alloc_chrdev_region(&dev, 0, sis_char_devs_count, SIS_DEVICE_NAME);
		
	if (alloc_ret)
		goto error;
		
	sis_char_major  = MAJOR(dev);
	cdev_init(&sis_char_cdev, &sis_cdev_fops);
	sis_char_cdev.owner = THIS_MODULE;
	cdev_err = cdev_add(&sis_char_cdev, MKDEV(sis_char_major, 0), sis_char_devs_count);
	if (cdev_err) 
		goto error;

	if (hdev->product == USB_DEVICE_ID_SISF817_TOUCH)
		printk(KERN_INFO "%s driver(major %d) installed.\n", SIS_BRIDGE_DEVICE_NAME, sis_char_major);
	else
		printk(KERN_INFO "%s driver(major %d) installed.\n", SIS_DEVICE_NAME, sis_char_major);

	// register class
	if (hdev->product == USB_DEVICE_ID_SISF817_TOUCH)
		sis_char_class = class_create(THIS_MODULE, SIS_BRIDGE_DEVICE_NAME);
	else
		sis_char_class = class_create(THIS_MODULE, SIS_DEVICE_NAME);

	if (IS_ERR(ptr_err = sis_char_class))
		goto err2;

	if (hdev->product == USB_DEVICE_ID_SISF817_TOUCH)
		class_dev = device_create(sis_char_class, NULL, MKDEV(sis_char_major, 0), NULL, SIS_BRIDGE_DEVICE_NAME);
	else
		class_dev = device_create(sis_char_class, NULL, MKDEV(sis_char_major, 0), NULL, SIS_DEVICE_NAME);

	if (IS_ERR(ptr_err = class_dev)) 
		goto err;
	
	return 0;
error:
	if (cdev_err == 0)
		cdev_del(&sis_char_cdev);
	if (alloc_ret == 0)
		unregister_chrdev_region(MKDEV(sis_char_major, 0), sis_char_devs_count);
	if (input_err != 0)
		printk("sis_ts_bak error!\n");
err:
	device_destroy(sis_char_class, MKDEV(sis_char_major, 0));
err2:
	class_destroy(sis_char_class);
	return -1;
}
EXPORT_SYMBOL(sis_setup_chardev);

void sis_deinit_chardev(void)
{
	//for ioctl
	dev_t dev;
	printk(KERN_INFO "sis_remove\n");

	dev = MKDEV(sis_char_major, 0);
	cdev_del(&sis_char_cdev);
	unregister_chrdev_region(dev, sis_char_devs_count);
	device_destroy(sis_char_class, MKDEV(sis_char_major, 0));
	class_destroy(sis_char_class);
	usb_kill_urb(backup_urb);
	usb_free_urb(backup_urb);
	backup_urb = NULL;
	hid_dev_backup = NULL;
	
}
EXPORT_SYMBOL(sis_deinit_chardev);
#endif	//CONFIG_HID_SIS_UPDATE_FW

static int sis_mt_probe(struct hid_device *hdev, const struct hid_device_id *id)
{
	int ret;
	struct sis_mt_device *td;

	/* This allows the driver to correctly support devices
	 * that emit events over several HID messages.
	 */
	hdev->quirks |= HID_QUIRK_NO_INPUT_SYNC;

	td = kzalloc(sizeof(struct sis_mt_device), GFP_KERNEL);
	if (!td) {
		dev_err(&hdev->dev, "cannot allocate multitouch data\n");
		return -ENOMEM;
	}
	td->inputmode = -1;
	td->last_mt_collection = -1;
	hid_set_drvdata(hdev, td);

	ret = hid_parse(hdev);
	if (ret != 0)
		goto fail;

	//SiS set noget for not init reports
	if (hdev->vendor == USB_VENDOR_ID_SIS_TOUCH) {
		hdev->quirks |= HID_QUIRK_NOGET;
		printk(KERN_INFO "sis:sis-probe: quirk = %x\n", hdev->quirks);

		//SiS FW update
#ifdef CONFIG_HID_SIS_UPDATE_FW
		ret = sis_setup_chardev(hdev);
		if (ret)
			printk( KERN_INFO "sis_setup_chardev fail\n");
#endif	//CONFIG_HID_SIS_UPDATE_FW
	}

	ret = hid_hw_start(hdev, HID_CONNECT_DEFAULT);
	if (ret)
		goto fail;

	td->slots = kzalloc(td->maxcontacts * sizeof(struct sis_mt_slot),
				GFP_KERNEL);
	if (!td->slots) {
		dev_err(&hdev->dev, "cannot allocate multitouch slots\n");
		hid_hw_stop(hdev);
		ret = -ENOMEM;
		goto fail;
	}

	sis_mt_set_input_mode(hdev);

	return 0;

fail:
	kfree(td);
	return ret;
}

#ifdef CONFIG_PM
static int sis_mt_reset_resume(struct hid_device *hdev)
{
	sis_mt_set_input_mode(hdev);
	return 0;
}
#endif

static void sis_mt_remove(struct hid_device *hdev)
{
	struct sis_mt_device *td = hid_get_drvdata(hdev);

	//SiS FW update
	if (hdev->vendor == USB_VENDOR_ID_SIS_TOUCH) {
#ifdef CONFIG_HID_SIS_UPDATE_FW
		sis_deinit_chardev();
#endif	//CONFIG_HID_SIS_UPDATE_FW
	}

	hid_hw_stop(hdev);
	kfree(td->slots);
	kfree(td);
	hid_set_drvdata(hdev, NULL);
}

static const struct hid_device_id sis_mt_devices[] = {
	{ HID_USB_DEVICE(USB_VENDOR_ID_SIS_TOUCH, HID_ANY_ID) },	//0x0457
	{ }
};
MODULE_DEVICE_TABLE(hid, sis_mt_devices);

static const struct hid_usage_id sis_mt_grabbed_usages[] = {
	{ HID_ANY_ID, HID_ANY_ID, HID_ANY_ID },
	{ HID_ANY_ID - 1, HID_ANY_ID - 1, HID_ANY_ID - 1}
};

static struct hid_driver sis_mt_driver = {
	.name = "hid-sis",
	.id_table = sis_mt_devices,
	.probe = sis_mt_probe,
	.remove = sis_mt_remove,
	.input_mapping = sis_mt_input_mapping,
	.input_mapped = sis_mt_input_mapped,
	.usage_table = sis_mt_grabbed_usages,
	.event = sis_mt_event,
#ifdef CONFIG_PM
	.reset_resume = sis_mt_reset_resume,
#endif
};

static int __init sis_mt_init(void)
{
	return hid_register_driver(&sis_mt_driver);
}

static void __exit sis_mt_exit(void)
{
	hid_unregister_driver(&sis_mt_driver);
}

module_init(sis_mt_init);
module_exit(sis_mt_exit);
